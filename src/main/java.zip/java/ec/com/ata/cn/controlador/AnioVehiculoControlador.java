/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.com.ata.cn.controlador;

import javax.faces.view.ViewScoped;
import javax.inject.Named;

/**
 *
 * @author ATA1
 */
@ViewScoped
@Named
public class AnioVehiculoControlador extends BaseControlador{
    /*@Inject
    private AnioVe|*/
}
